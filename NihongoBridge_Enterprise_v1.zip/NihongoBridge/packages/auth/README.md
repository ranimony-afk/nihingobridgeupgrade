# Shared Auth utilities
