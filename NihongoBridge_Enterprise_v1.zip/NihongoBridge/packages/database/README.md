# Shared Database connection adapters
