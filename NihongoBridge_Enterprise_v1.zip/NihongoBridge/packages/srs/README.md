# Spaced repetition adapters
