# Search indexing algorithms
